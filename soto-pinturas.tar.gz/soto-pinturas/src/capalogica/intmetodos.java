/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capalogica;

import javax.swing.DefaultListModel;
import javax.swing.JComboBox;


/**
 *
 * @author dextre
 */
public interface intmetodos  {
    void llenarcombo(JComboBox cboObras);
    void llenarpinturas(DefaultListModel lstpinturas, int ordenobras);
    double precio(double ordenobras, double ordenpinturas);
    double total(double precio, double cantidad);
}
