/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capalogica;

import javax.swing.DefaultListModel;
import javax.swing.JComboBox;

/**
 *
 * @author dextre
 */
public class clasemetodos implements intmetodos{

    @Override
    public void llenarcombo(JComboBox cboObras) {
        cboObras.addItem("Oleo");
        cboObras.addItem("Acuarela");
        
    }

    @Override
    public void llenarpinturas(DefaultListModel lstpinturas, int ordenobras) {
        lstpinturas.addElement("Paisajes");
        lstpinturas.addElement("Bodegones");
        lstpinturas.addElement("Marinas");
        
    }
    public void llenarpinturas2(DefaultListModel lstpinturas, int ordenobras) {
        lstpinturas.addElement("Calles");
        lstpinturas.addElement("Portones");
        lstpinturas.addElement("Balcones");
        
    }
    
    
    
    
    
  //  @Override
    public double precio(int ordenobras, int ordenpinturas) {
        switch (ordenobras){ //esto es el que cambia del ComboBox
            case 1: //esto es de los oleos
                switch (ordenpinturas){
                    case 0: return 80;
                    case 1: return 120;
                    case 2: return 90;
                }
            case 2: //esto es de las acuarelas
                switch  (ordenpinturas){
                    case 0: return 100;
                    case 1: return 120;
                    case 2: return 70;
                }
            
        }
        
        
        return 0;
    }

    @Override
    public double total(double precio, double cantidad) {
        return precio*cantidad;
        
        
        
    }

    @Override
    public double precio(double ordenobras, double ordenpinturas) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
