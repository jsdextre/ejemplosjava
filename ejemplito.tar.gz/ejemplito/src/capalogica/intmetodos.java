/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capalogica;

import javax.swing.DefaultListModel;
import javax.swing.JComboBox;

/**
 *
 * @author soto
 */
public interface intmetodos {
    void llenartipoplan(JComboBox cbotipoplan, int ordentipoplan );
    void llenarlstmarcas(DefaultListModel lstmarcas, int ordenmarcas);
    void llenarmodelos (DefaultListModel lstmodelos, int ordenmodelos);
    double numeroderegistro (double registro);
    double numerodni(double dni);
    String nombredeloperador(String operador);
    double costodelequipo(double costoequipo);
    double costoporplan(double costoporplan);
    double impuesto(double igv);
    double costototal(double total);
    
}
