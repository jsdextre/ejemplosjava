/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capalogica;

import java.awt.Image;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;

/**
 *
 * @author soto
 */
public class clasemetodos implements intmetodos{

    @Override
    public void llenartipoplan(JComboBox cbotipoplan, int ordentipoplan) {
        cbotipoplan.addItem("prepago");
        cbotipoplan.addItem("post-pago");
        
    }

    @Override
    public void llenarlstmarcas(DefaultListModel lstmarcas, int ordenmarcas) {
        lstmarcas.addElement("sony");
        lstmarcas.addElement("motorola");
        lstmarcas.addElement("huawei");
        lstmarcas.addElement("samsung");
        
        
    }
//    @Override
    public void llenarlstmarcas2 (DefaultListModel lstmarcas, int ordenmarcas) {
        lstmarcas.addElement("LG");
        lstmarcas.addElement("Blackberry");
        lstmarcas.addElement("Iphone");
        lstmarcas.addElement("nokia");
    }
    
    
    
    //@Override
    public void llenarmodelosClaro1(DefaultListModel lstmodelos, int ordenmodelos1) {
        lstmodelos.addElement("xperia");
        
        lstmodelos.addElement("xperia xZ");
        
        lstmodelos.addElement("Xperia E5");
        
        lstmodelos.addElement("Xperia Z5 Premium");
        
    }
    //@Override
    public void llenarmodelosClaro2 (DefaultListModel lstmodelos, int ordenmodelos2) {
        lstmodelos.addElement("Moto G de 8GB");
        lstmodelos.addElement("Moto XZ");
        lstmodelos.addElement("Motorola premium");
        lstmodelos.addElement("Moto g de 16GB");
    }
    
     public void llenarmodelosClaro3 (DefaultListModel lstmodelos, int ordenmodelos3) {
        lstmodelos.addElement("Huawei mate8");
        lstmodelos.addElement("Huawei p9 plus");
        lstmodelos.addElement("Huawei mate S");
        lstmodelos.addElement("Huawei Honor");
    }
     public void llenarmodelosClaro4 (DefaultListModel lstmodelos, int ordenmodelos4) {
        lstmodelos.addElement("Samsung galaxi c7 pro");
        lstmodelos.addElement("Samsung galaxi a7");
        lstmodelos.addElement("Samsung galaxi s7 duos");
        lstmodelos.addElement("Samsung c9 pro");
    }
    
     
    //@Override
    public void llenarmodelosMovistar1(DefaultListModel lstmodelos, int ordenmodelos5) {
        lstmodelos.addElement("LG Ultra");
        lstmodelos.addElement("LG Basic");
        lstmodelos.addElement("LG Mate");
        lstmodelos.addElement("LG Premium");
    }
    //@Override
    public void llenarmodelosMovistar2 (DefaultListModel lstmodelos, int ordenmodelos6) {
        lstmodelos.addElement("Blackberry 9320");
        lstmodelos.addElement("Blackberry touch");
        lstmodelos.addElement("Blackberry 9000");
        lstmodelos.addElement("Blackberry Pri");
    }
    
     public void llenarmodelosMovistar3 (DefaultListModel lstmodelos, int ordenmodelos7) {
        lstmodelos.addElement("Iphone Monc");
        lstmodelos.addElement("Iphone s4");
        lstmodelos.addElement("Iphone 7");
        lstmodelos.addElement("Iphone 6");
    }
     public void llenarmodelosMovistar4 (DefaultListModel lstmodelos, int ordenmodelos8) {
        lstmodelos.addElement("Nokia 1100");
        lstmodelos.addElement("Nokia basico");
        lstmodelos.addElement("Nokia con android");
        lstmodelos.addElement("Nokia lumia2");
    }
    
    
    
    @Override
    public double numeroderegistro(double registro) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public double numerodni(double dni) {
       
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public String nombredeloperador(String operador) {
        operador="claro";
        operador="movistar";
        return null;
        
    }

    @Override
    public double costodelequipo(double costoequipo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public double costoporplan(double costoporplan) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public double impuesto(double igv) {
       igv=0.18;
        return 0;
    }

    //@Override
    public double costototal(double total, double costoequipo,double costoporplan, double igv) {
        total=costoequipo+costoporplan+igv;
        return 0;
    }    

    @Override
    public double costototal(double total) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void llenarmodelos(DefaultListModel lstmodelos, int ordenmodelos) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
        
    
    
}
