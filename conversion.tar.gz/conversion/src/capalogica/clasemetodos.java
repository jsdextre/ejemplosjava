/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capalogica;

/**
 *
 * @author jsd
 */
public class clasemetodos implements intmetodos {

    @Override
    public double solanos(double soles) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public double dolares(double dolar) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    //@Override
    public double solanos(double soles, double n1) {
        return soles=n1;
        
    }

    //@Override
    public double dolares(double dolar, double n2) {
        return dolar=n2;
                
    }

    public double resultado(double resultado, double soles, double dolar,double n3) {
        return resultado=n3;
        
    }

    @Override
    public double resultado(double resultado) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
